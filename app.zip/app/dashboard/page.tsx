"use client";

import styles from "./page.module.scss";
import { useRouter } from "next/navigation";
import { useTradeStore, WaitingTrade } from "../store/TradeStore";

const watchlist = [
  { symbol: "NIFTY 10MAR26 24600 CE", ltp: "200.00" },
  { symbol: "NIFTY 10MAR26 24700 CE", ltp: "180.05" },
  { symbol: "NIFTY 10MAR26 24800 CE", ltp: "124.90" },
  { symbol: "NIFTY 10MAR26 24900 PE", ltp: "200.10" },
];

const activeTrades = [
  {
    symbol: "NIFTY 10MAR26 24800 CE",
    pnlText: "+2345.75",
    pnlVariant: "profit" as const,
    actionText: "EXIT",
    actionVariant: "dark" as const,
    logs: [
      "09:31  Condition1 true",
      "09:31  Condition2 true",
      "09:31  BUY signal",
    ],
  },
  {
    symbol: "NIFTY 10MAR26 24900 PE",
    pnlText: "-320.00",
    pnlVariant: "loss" as const,
    actionText: "EXIT",
    actionVariant: "dark" as const,
    logs: ["Logs comes here","Logs comes here","Logs comes here","Logs comes here","Logs comes here","Logs comes here","Logs comes here","Logs comes here","Logs comes here"],
  },
];

export default function DashboardPage() {
  const router = useRouter();
  const { setSelection, waitingTrades, removeWaitingTrade } = useTradeStore();

  return (
    <div className={styles.page}>
      <div className={styles.container}>
        <header className={styles.header}>
          <input className={styles.search} placeholder="" />
          <button className={styles.addBtn} type="button">
            ADD
          </button>
        </header>

        <h2 className={styles.sectionTitle}>WATCHLIST</h2>

        <div className={styles.card}>
          <div className={styles.tableHeader}>
            <div className={styles.thLeft}>SYMBOL</div>
            <div className={styles.thRight}>LTP</div>
            <div className={styles.thIcon} />
          </div>

          <div className={styles.rows}>
            {watchlist.map((row) => (
              <div key={row.symbol} className={styles.row}>
                <button
                  className={styles.symbolButton}
                  type="button"
                  onClick={() => {
                    setSelection({ symbol: row.symbol, price: row.ltp });
                    router.push("/trade");
                  }}
                >
                  {row.symbol}
                </button>
                <div className={styles.ltp}>{row.ltp}</div>
                <button className={styles.trash} type="button" aria-label="delete">
                  🗑️
                </button>
              </div>
            ))}
          </div>
        </div>

        <h2 className={styles.sectionTitle}>ACTIVE TRADES</h2>

        <div className={styles.card}>
          <div className={styles.activeTrades}>
            {waitingTrades.map((t: WaitingTrade, index: number) => (
              <div key={index} className={styles.trade}>
                <div className={styles.tradeRow}>
                  <div className={styles.tradeSymbol}>{t.symbol}</div>

                  <div className={styles.tradeRight}>
                    <div className={`${styles.tradeMeta} ${styles.waiting}`}>{t.stateText}</div>

                    <button
                      className={`${styles.tradeAction} ${styles.danger}`}
                      type="button"
                      onClick={() => removeWaitingTrade(t.symbol)}
                    >
                      CANCEL
                    </button>
                  </div>
                </div>

                {t.logs.length > 0 ? (
                  <div className={styles.tradeLogs}>
                    {t.logs.map((line: string, index: number) => (
                      <div key={index} className={styles.logLine}>
                        {line}
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            ))}

            {activeTrades.map((t) => (
              <div key={t.symbol} className={styles.trade}>
                <div className={styles.tradeRow}>
                  <div className={styles.tradeSymbol}>{t.symbol}</div>

                  <div className={styles.tradeRight}>
                    <div
                      className={`${styles.tradeMeta} ${
                        t.pnlVariant === "profit" ? styles.profit : styles.loss
                      }`}
                    >
                      {t.pnlText}
                    </div>

                    <button
                      className={`${styles.tradeAction} ${styles.dark}`}
                      type="button"
                    >
                      {t.actionText}
                    </button>
                  </div>
                </div>

                {t.logs.length > 0 ? (
                  <div className={styles.tradeLogs}>
                    {t.logs.map((line, index) => (
                      <div key={index} className={styles.logLine}>
                        {line}
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            ))}
          </div>
        </div>

        <div className={styles.bottomActions}>
          <button
            className={styles.bottomBtn}
            type="button"
            onClick={() => router.push("/account-details")}
          >
            ACCOUNT DETAILS
          </button>
          <button
            className={styles.bottomBtn}
            type="button"
            onClick={() => router.push("/trade-history")}
          >
            TRADE HISTORY
          </button>
        </div>
      </div>
    </div>
  );
}
